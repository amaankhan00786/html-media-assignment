let change  = document.getElementById("container");


change.addEventListener("click",  () => {
    change.style.backgroundColor = "red";
})